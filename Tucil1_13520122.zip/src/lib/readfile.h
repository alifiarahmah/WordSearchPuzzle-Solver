/* readfile.h */
/* Header file untuk readfile.cpp */

#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>
#include "readfile.cpp"
using namespace std;

void readFile(string *filename, vector<vector<char>> *matrix, vector<string> *wordlist);
